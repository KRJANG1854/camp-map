# Camp Map (Fixed)

Single-file HTML app for placing weekday/number labels on a fixed campsite map.

## How to deploy to GitHub Pages
1. Create a repository (public or private). Name example: `camp-map`.
2. Upload `index.html` to the root of the repository and Commit.
3. Go to **Settings → Pages**.
4. Set **Source** to `Deploy from a branch`.
5. Select **Branch**: `main` and **Folder**: `/ (root)` → Save.
6. Wait ~1 minute. Your site will be available at:
   `https://<your-username>.github.io/camp-map/`

Open the URL on iPhone Safari → Share → Add to Home Screen.